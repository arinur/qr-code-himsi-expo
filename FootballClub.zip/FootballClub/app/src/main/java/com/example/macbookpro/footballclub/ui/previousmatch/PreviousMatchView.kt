package com.example.macbookpro.footballclub.ui.previousmatch

import com.example.macbookpro.footballclub.BaseView
import com.example.macbookpro.footballclub.models.MatchEvent

/**
 * Created by macbookpro on 9/27/18.
 */
interface PreviousMatchView : BaseView {
    fun onPrevMatchData(matches: MatchEvent)
}