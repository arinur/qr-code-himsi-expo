package com.example.macbookpro.footballclub


interface BasePresenterImpl<V> {
    fun onFinishRequest()
    fun catchError(error: Throwable)
    fun attachView(view: V)
    fun dettachView()
    fun view(): V
}