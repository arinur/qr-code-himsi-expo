package com.example.macbookpro.footballclub.ui.nextmatch

import com.example.macbookpro.footballclub.BasePresenter
import com.example.macbookpro.footballclub.models.MatchEvent
import com.example.macbookpro.footballclub.utils.reactive.ScheduleUtils



class NextMatchPresenter(view: NextMatchView) : BasePresenter<NextMatchView>() {

    init { super.attachView(view) }

    fun getNextMatch() {
        view().showLoading()
        subscribe(getService().nextMatch("4328")
                .compose(ScheduleUtils.set<MatchEvent>())
                .subscribe(
                        { res ->
                            run {
                                view().onNextMatchData(res)
                                onFinishRequest()
                            }
                        },
                        this::catchError
                ))
    }

}