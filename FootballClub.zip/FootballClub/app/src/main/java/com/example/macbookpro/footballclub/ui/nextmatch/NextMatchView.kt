package com.example.macbookpro.footballclub.ui.nextmatch

import com.example.macbookpro.footballclub.BaseView
import com.example.macbookpro.footballclub.models.MatchEvent


interface NextMatchView : BaseView {
    fun onNextMatchData(matches: MatchEvent)
}