package com.example.macbookpro.footballclub.utils.reactive


object ScheduleUtils {
    fun <T> set(): MainScheduler<T> = MainScheduler()
}