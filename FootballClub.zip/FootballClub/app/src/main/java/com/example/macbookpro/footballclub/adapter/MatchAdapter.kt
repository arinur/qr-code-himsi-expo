package com.example.macbookpro.footballclub.adapter

import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import com.example.macbookpro.footballclub.R
import com.example.macbookpro.footballclub.models.Match
import com.example.macbookpro.footballclub.ui.detailmatch.DetailMatchActivity
import org.jetbrains.anko.*



class MatchAdapter(private var matches: List<Match>): RecyclerView.Adapter<MatchAdapter.Holder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {
        val viewHolder = Holder(LayoutInflater.from(parent?.context).inflate(R.layout.match_list, parent, false))
        viewHolder.itemView.setOnClickListener {
            val position = viewHolder.adapterPosition
            parent?.context?.startActivity<DetailMatchActivity>("match" to matches[position])
        }
        return viewHolder
    }

    override fun onBindViewHolder(holder: Holder, position: Int) {
        holder?.setMatchData(matches[position])
    }

    override fun getItemCount(): Int = matches.size

    inner class Holder(view: View?): RecyclerView.ViewHolder(view) {
        private val tvTeamLeft = view?.findViewById<TextView>(R.id.tvTeamLeft)
        private val tvTeamRight = view?.findViewById<TextView>(R.id.tvTeamRight)
        private val tvScoreLeft = view?.findViewById<TextView>(R.id.tvScoreLeft)
        private val tvScoreRight = view?.findViewById<TextView>(R.id.tvScoreRight)
        private val tvDate = view?.findViewById<TextView>(R.id.tvDate)

        fun setMatchData(match: Match) {
            tvTeamLeft?.text = match.strHomeTeam
            tvTeamRight?.text = match.strAwayTeam
            tvDate?.text = match.dateEvent

            if (match.intHomeScore !== null) {
                val homeScore: Int? = match.intHomeScore?.toInt() ?: 0
                val awayScore: Int? = match.intAwayScore?.toInt() ?: 0
                tvTeamLeft?.text = "${match.strHomeTeam}"
                tvTeamRight?.text = "${match.strAwayTeam}"
                tvScoreLeft?.text = "$homeScore"
                tvScoreRight?.text = "$awayScore"
            }
        }
    }

}