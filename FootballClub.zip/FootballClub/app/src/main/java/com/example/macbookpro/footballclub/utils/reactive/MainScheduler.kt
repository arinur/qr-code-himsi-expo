package com.example.macbookpro.footballclub.utils.reactive

import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers


class MainScheduler<T>: SchedulerTransformer<T>(Schedulers.io(), AndroidSchedulers.mainThread())