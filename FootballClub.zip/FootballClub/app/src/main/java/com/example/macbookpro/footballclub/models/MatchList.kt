package com.example.macbookpro.footballclub.models

data class MatchList (val date: String?,val event: String? , val homeScore: Int? , val awayScore: Int?)