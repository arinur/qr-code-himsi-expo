package com.example.macbookpro.footballclub.ui.detailmatch

import android.content.Context
import android.database.sqlite.SQLiteConstraintException
import com.example.macbookpro.footballclub.BasePresenter
import com.example.macbookpro.footballclub.models.Match
import com.example.macbookpro.footballclub.models.TeamRepository
import com.example.macbookpro.footballclub.storage.FavoriteEntity
import com.example.macbookpro.footballclub.storage.database
import io.reactivex.Single
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.functions.BiFunction
import io.reactivex.schedulers.Schedulers
import org.jetbrains.anko.db.delete
import org.jetbrains.anko.db.insert

/**
 * Created by macbookpro on 10/2/18.
 */
class DetailMatchPresenter(view: DetailMatchView) : BasePresenter<DetailMatchView>() {

    init { super.attachView(view) }

   // @Test
    fun getTeamsBadge(homeTeam: String, awayTeam: String) {
        view().showLoading()
        subscribe(
                Single.zip(
                        getService().teamDetail(homeTeam),
                        getService().teamDetail(awayTeam),
                        BiFunction<TeamRepository, TeamRepository, List<String>> { t1, t2 ->
                            listOf(t1.teams[0].strTeamBadge, t2.teams[0].strTeamBadge)
                        })
                        .subscribeOn(Schedulers.io())
                        .observeOn(AndroidSchedulers.mainThread())
                        .subscribe(
                                { res ->
                                    run {
                                        onFinishRequest()
                                        view().getTeamsBadge(res[0], res[1])
                                    }
                                },
                                this::catchError
                        ))
    }
    fun addToFavorite(context: Context, match: Match) = try {
        context.database.use {
            insert(FavoriteEntity.TABLE_FAVORITE,
                    FavoriteEntity.EVENT_ID to match.idEvent,
                    FavoriteEntity.MATCH_HOME_ID to match.idHomeTeam,
                    FavoriteEntity.MATCH_AWAY_ID to match.idAwayTeam )
        }
        view().onInfo("Added to Favorite")
    } catch (e: SQLiteConstraintException) {
        view().onError(e.localizedMessage)
    }

    fun removeFromFavorite(context: Context, id: String) = try {
        context.database.use {
            delete(FavoriteEntity.TABLE_FAVORITE, "(EVENT_ID = {id})", "id" to id)
        }
        view().onInfo("Removed from Favorite")
    } catch (e: SQLiteConstraintException) {
        view().onError(e.localizedMessage)
    }


}