package com.example.macbookpro.footballclub.ui.favoritematch

import android.support.v7.widget.LinearLayoutManager
import com.example.macbookpro.footballclub.BaseFragment
import com.example.macbookpro.footballclub.R
import com.example.macbookpro.footballclub.R.id.listFavoriteMatch
import com.example.macbookpro.footballclub.R.id.swipeRefresh
import com.example.macbookpro.footballclub.adapter.MatchAdapter
import com.example.macbookpro.footballclub.models.Match
import com.example.macbookpro.footballclub.models.MatchEvent
import com.example.macbookpro.footballclub.ui.previousmatch.PreviousMatchFragment
import kotlinx.android.synthetic.main.fragment_favorite_match.*

/**
 * Created by macbookpro on 10/1/18.
 */
class FavoriteMatchFragment : BaseFragment<FavoriteMatchPresenter>(), FavoriteMatchView {

    override fun presenter(): FavoriteMatchPresenter = FavoriteMatchPresenter(this)
    override fun contentView(): Int = R.layout.fragment_favorite_match

    private var events : MutableList<Match> = mutableListOf()
    private var adapter = MatchAdapter(events)

    override fun onCreated() {
        listFavoriteMatch.layoutManager = LinearLayoutManager(context())
        listFavoriteMatch.adapter = adapter
        swipeRefresh.setOnRefreshListener { getFavoriteLocal() }
        swipeRefresh.post{
            swipeRefresh.isRefreshing = true
            getFavoriteLocal()
        }
    }

    private fun getFavoriteLocal() {
        events.clear()
        presenter().getNextMatch(context())
    }

    override fun onMatchData(matches: MatchEvent) {
        swipeRefresh.isRefreshing = false //TODO(harusnya masuk ke basePresenter)
        events.add(matches.events[0])
        adapter.notifyDataSetChanged()
    }
    companion object {
        fun newInstance(): FavoriteMatchFragment = FavoriteMatchFragment()
    }
}