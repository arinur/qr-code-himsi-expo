package com.example.macbookpro.footballclub.ui.previousmatch


import android.support.v7.widget.LinearLayoutManager
import com.example.macbookpro.footballclub.BaseFragment

import com.example.macbookpro.footballclub.R
import com.example.macbookpro.footballclub.models.MatchEvent
import com.example.macbookpro.footballclub.adapter.MatchAdapter
import kotlinx.android.synthetic.main.fragment_previous_match.*

class PreviousMatchFragment : BaseFragment<PreviousMatchPresenter>(), PreviousMatchView {

    override fun presenter(): PreviousMatchPresenter = PreviousMatchPresenter(this)
    override fun contentView(): Int = R.layout.fragment_previous_match

    override fun onCreated() {
        listPreviousMatch.layoutManager = LinearLayoutManager(context())
        presenter().getPrevMatch()
    }

    override fun onPrevMatchData(matches: MatchEvent) {
        listPreviousMatch.adapter = MatchAdapter(matches.events)
    }
    companion object {
        fun newInstance():  PreviousMatchFragment = PreviousMatchFragment()
    }

}