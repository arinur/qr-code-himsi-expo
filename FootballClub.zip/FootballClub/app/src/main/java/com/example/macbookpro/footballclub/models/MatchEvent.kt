package com.example.macbookpro.footballclub.models


data class MatchEvent(val events: List<Match>)