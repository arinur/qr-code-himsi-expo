package com.example.macbookpro.footballclub.utils


object DelimeterUtil {
    fun comma(str: String?): String? = str?.trim()?.replace(";", "\n")
}