package com.example.macbookpro.footballclub.storage

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import org.jetbrains.anko.db.*

/**
 * Created by macbookpro on 9/30/18.
 */
class DataHelper(ctx: Context) : ManagedSQLiteOpenHelper(ctx, "Favorites.db", null, 1) {

    companion object {
        private var instance: DataHelper? = null

        @Synchronized
        fun getInstance(ctx: Context): DataHelper {
            if (instance == null) instance = DataHelper(ctx.applicationContext)
            return instance as DataHelper
        }
    }

    override fun onCreate(db: SQLiteDatabase) {
        // Here you create tables
        db.createTable(FavoriteEntity.TABLE_FAVORITE, true,
                FavoriteEntity.ID to INTEGER + PRIMARY_KEY + AUTOINCREMENT,
                FavoriteEntity.EVENT_ID to TEXT + UNIQUE,
                FavoriteEntity.MATCH_HOME_ID to TEXT,
                FavoriteEntity.MATCH_AWAY_ID to TEXT)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // Here you can upgrade tables, as usual
        db.dropTable(FavoriteEntity.TABLE_FAVORITE, true)
    }

}

val Context.database: DataHelper get() = DataHelper.getInstance(applicationContext)