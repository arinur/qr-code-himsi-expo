package com.example.macbookpro.footballclub.ui.previousmatch

import com.example.macbookpro.footballclub.BasePresenter
import com.example.macbookpro.footballclub.models.MatchEvent
import com.example.macbookpro.footballclub.utils.reactive.ScheduleUtils

/**
 * Created by macbookpro on 9/27/18.
 */
class PreviousMatchPresenter(view: PreviousMatchView) : BasePresenter<PreviousMatchView>() {

    init { super.attachView(view) }

    fun getPrevMatch() {
        view().showLoading()
        subscribe(getService().prevMatch("4328")
                .compose(ScheduleUtils.set<MatchEvent>())
                .subscribe(
                        { res ->
                            run {
                                view().onPrevMatchData(res)
                                onFinishRequest()
                            }
                        },
                        this::catchError
                ))
    }

}