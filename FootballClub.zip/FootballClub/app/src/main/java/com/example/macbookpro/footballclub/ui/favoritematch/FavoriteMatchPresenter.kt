package com.example.macbookpro.footballclub.ui.favoritematch

import android.content.Context
import com.example.macbookpro.footballclub.BasePresenter
import com.example.macbookpro.footballclub.models.MatchEvent
import com.example.macbookpro.footballclub.storage.FavoriteEntity
import com.example.macbookpro.footballclub.storage.database
import com.example.macbookpro.footballclub.utils.reactive.ScheduleUtils
import io.reactivex.Single
import org.jetbrains.anko.db.classParser
import org.jetbrains.anko.db.select

/**
 * Created by macbookpro on 10/1/18.
 */
class FavoriteMatchPresenter(view: FavoriteMatchView) : BasePresenter<FavoriteMatchView>() {

    init { super.attachView(view) }

    private fun getMatchFavorite(context: Context?) : Single<List<FavoriteEntity>> {
        lateinit var favoriteList : List<FavoriteEntity>
        context?.database?.use {
            val result = select(FavoriteEntity.TABLE_FAVORITE)
            val favorite = result.parseList(classParser<FavoriteEntity>())
            favoriteList = favorite
        }
        return Single.just(favoriteList)
    }

    fun getNextMatch(context: Context?) {
        view().showLoading()
        subscribe(getMatchFavorite(context)
                .flattenAsFlowable{ it }
                .flatMap({ getService().getMatchById(it.eventId.toString()) })
                .compose(ScheduleUtils.set<MatchEvent>())
                .subscribe(
                        { res ->
                            run {
                                view().onMatchData(res)
                                onFinishRequest()
                            }
                        },
                        this::catchError
                ))
    }

}