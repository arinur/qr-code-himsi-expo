package com.example.macbookpro.footballclub.ui.favoritematch

import com.example.macbookpro.footballclub.BaseView
import com.example.macbookpro.footballclub.models.MatchEvent

/**
 * Created by macbookpro on 10/1/18.
 */
interface FavoriteMatchView : BaseView {
    fun onMatchData(matches: MatchEvent)
}