package com.example.macbookpro.footballclub.ui

import android.os.Bundle
import android.support.design.widget.BottomNavigationView
import android.support.v4.app.Fragment
import android.support.v7.app.AppCompatActivity
import com.example.macbookpro.footballclub.R
import com.example.macbookpro.footballclub.ui.favoritematch.FavoriteMatchFragment
import com.example.macbookpro.footballclub.ui.nextmatch.NextMatchFragment
import com.example.macbookpro.footballclub.ui.previousmatch.PreviousMatchFragment
import kotlinx.android.synthetic.main.activity_match_schedule.*

class MatchScheduleActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_match_schedule)
        setupViewPagerMain()
        onBottomBarSelected()
        navigation.selectedItemId = R.id.navigation_previous_match
    }

    private fun setupViewPagerMain() {
        viewpagerMain.setPagingEnabled(false)
        viewpagerMain.offscreenPageLimit = 3

        val adapter = ViewPagerAdapter(supportFragmentManager)
        adapter.addFragment(PreviousMatchFragment())
        adapter.addFragment(NextMatchFragment())
        adapter.addFragment(FavoriteMatchFragment())
        viewpagerMain.adapter = adapter
    }

    private fun onBottomBarSelected() = navigation.setOnNavigationItemSelectedListener { item ->
        when(item.itemId) {
            R.id.navigation_previous_match -> viewpagerMain.currentItem = 0
            R.id.navigation_next_match -> viewpagerMain.currentItem = 1
            R.id.navigation_favorite_match -> viewpagerMain.currentItem = 2
        }
        true
    }

}
