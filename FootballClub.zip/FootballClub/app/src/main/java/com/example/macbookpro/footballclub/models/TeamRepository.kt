package com.example.macbookpro.footballclub.models


data class TeamRepository(val teams: List<Team>)