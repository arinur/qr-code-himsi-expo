package com.example.macbookpro.footballclub.ui.detailmatch

import android.support.v4.content.ContextCompat
import android.view.Menu
import android.view.MenuItem
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.example.macbookpro.footballclub.BaseActivity
import com.example.macbookpro.footballclub.R
import com.example.macbookpro.footballclub.models.Match
import com.example.macbookpro.footballclub.storage.FavoriteEntity
import com.example.macbookpro.footballclub.storage.database
import kotlinx.android.synthetic.main.activity_detail_match.*
import org.jetbrains.anko.db.classParser
import org.jetbrains.anko.db.select

class DetailMatchActivity : BaseActivity<DetailMatchPresenter>(), DetailMatchView {

    private lateinit var match: Match
    private var isFavorite: Boolean = false
    private var menuItem: Menu? = null

    override fun presenter(): DetailMatchPresenter = DetailMatchPresenter(this)
    override fun contentView(): Int = R.layout.activity_detail_match



    override fun getTeamsBadge(homeBadge: String, awayBadge: String) {
        Glide.with(applicationContext)
                .load(homeBadge)
                .apply(RequestOptions().placeholder(R.mipmap.ic_launcher_round))
                .into(imgTeamLeft)

        Glide.with(applicationContext)
                .load(awayBadge)
                .apply(RequestOptions().placeholder(R.mipmap.ic_launcher_round))
                .into(imgTeamRight)
    }

    override fun onCreated() {
        match = intent.getSerializableExtra("match") as Match
        showBackButton(true)
        matchDetail(match)
    }
    fun matchDetail(match: Match) {
        presenter().getTeamsBadge(match.idHomeTeam, match.idAwayTeam)
        tvDate.text = match.dateEvent

        //home
        tvTeamLeft.text = match.strHomeTeam
        tvPlayerGoalLeft.text = match.strHomeGoalDetails
        tvScoreLeft.text = match.intHomeScore
        tvShotLeft.text = match.intHomeShots

        tvGoalKeeperLeft.text = match.strHomeLineupGoalkeeper
        tvDefenseLeft.text = match.strHomeLineupDefense
        tvMidFieldLeft.text = match.strHomeLineupMidfield
        tvForwardLeft.text = match.strHomeLineupForward
        tvSubtitutesLeft.text = match.strHomeLineupSubstitutes

        //away
        tvTeamRight.text = match.strAwayTeam
        tvPlayerGoalRight.text = match.strAwayGoalDetails
        tvScoreRight.text = match.intAwayScore
        tvShotRight.text = match.intAwayShots

        tvGoalKeeperRight.text = match.strAwayLineupGoalkeeper
        tvDefenseRight.text = match.strAwayLineupDefense
        tvMidFieldRight.text = match.strAwayLineupMidfield
        tvForwardRight.text = match.strAwayLineupForward
        tvSubtitutesRight.text = match.strAwayLineupSubstitutes
        //Log.d("DetailMatchActivity" , match.toString())
    }
    private fun setFavorite() = if (isFavorite) {
        menuItem?.getItem(0)?.icon = ContextCompat.getDrawable(this, R.drawable.icon_favorite)
    } else {
        menuItem?.getItem(0)?.icon = ContextCompat.getDrawable(this, R.drawable.icon_unfavorite)
    }
    private fun favoriteState() = database.use {
        val result = select(FavoriteEntity.TABLE_FAVORITE).whereArgs("(EVENT_ID = {id})", "id" to match.idEvent)
        val favorite = result.parseList(classParser<FavoriteEntity>())
        if (!favorite.isEmpty()) isFavorite = true
        setFavorite()
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.favorite_menu, menu)
        menuItem = menu
        favoriteState()
        return super.onCreateOptionsMenu(menu)
    }
    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        when (item?.itemId) {
            R.id.mnFavorite -> {
                isFavorite = if (!isFavorite) {
                    presenter().addToFavorite(this, match)
                    !isFavorite
                } else {
                    presenter().removeFromFavorite(this, match.idEvent)
                    !isFavorite
                }
                setFavorite()
            }
        }
        return super.onOptionsItemSelected(item)
    }



}

