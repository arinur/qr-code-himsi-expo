package com.example.macbookpro.footballclub.ui.detailmatch

import com.example.macbookpro.footballclub.BaseView

/**
 * Created by macbookpro on 10/2/18.
 */
interface DetailMatchView : BaseView {
    fun getTeamsBadge(homeBadge : String , awayBadge : String)
}