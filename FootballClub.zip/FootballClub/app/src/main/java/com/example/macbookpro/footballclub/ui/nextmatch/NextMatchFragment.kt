package com.example.macbookpro.footballclub.ui.nextmatch

import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v7.widget.LinearLayoutManager
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.example.macbookpro.footballclub.BaseFragment

import com.example.macbookpro.footballclub.R
import com.example.macbookpro.footballclub.models.MatchEvent
import com.example.macbookpro.footballclub.adapter.MatchAdapter
import kotlinx.android.synthetic.main.fragment_next_match.*

class NextMatchFragment : BaseFragment<NextMatchPresenter>(), NextMatchView {

    override fun presenter(): NextMatchPresenter = NextMatchPresenter(this)
    override fun contentView(): Int = R.layout.fragment_next_match

    override fun onCreated() {
        listNextMatch.layoutManager = LinearLayoutManager(context())
        presenter().getNextMatch()
    }

    override fun onNextMatchData(matches: MatchEvent) {
        listNextMatch.adapter = MatchAdapter(matches.events)
    }
    companion object {
        fun newInstance():  NextMatchFragment = NextMatchFragment()
    }
}