package com.example.macbookpro.footballclub

import com.example.macbookpro.footballclub.models.MatchEvent
import com.example.macbookpro.footballclub.network.Network
import com.example.macbookpro.footballclub.network.Routes
import com.example.macbookpro.footballclub.ui.nextmatch.NextMatchView
import com.example.macbookpro.footballclub.ui.previousmatch.PreviousMatchPresenter
import com.example.macbookpro.footballclub.ui.previousmatch.PreviousMatchView
import com.example.macbookpro.footballclub.utils.reactive.MainScheduler
import com.example.macbookpro.footballclub.utils.reactive.ScheduleUtils
import org.junit.Before
import org.junit.Test
import org.mockito.Mock
import org.mockito.Mockito
import org.mockito.Mockito.mock
import org.mockito.Mockito.verify
import org.mockito.MockitoAnnotations

/**
 * Created by macbookpro on 10/14/18.
 */
class ApiRepositoryTest {
    @Mock
    private lateinit var view: NextMatchView
/*
    @Mock
    private lateinit var matchRepository: MatchRepository*/

    @Mock
    private lateinit var matchResponse: MatchEvent


    @Mock
    private lateinit var routes: Routes

    @Mock
    private lateinit var scheduleUtils : ScheduleUtils

   /* private lateinit var matchPresenter: PreviousMatchPresenter


    @Before
    fun setUp() {
        MockitoAnnotations.initMocks(this)

        matchPresenter = PreviousMatchPresenter(view)
    }

    @Test
    fun getMatchLoadedTest() {

       // val id = "4328"

        matchPresenter.getPrevMatch()

        argumentCaptor<MatchRepositoryCallback<MatchResponse?>>().apply {

            verify(matchRepository).getNextMatch(eq(id), capture())
            firstValue.onDataLoaded(matchResponse)
        }

        matchResponse =

        //Mockito.verify(view).onShowLoading()
        Mockito.verify(view).onPrevMatchData(matchResponse)
        //Mockito.verify(view).onHideLoading()
    }

   /* @Test
    fun getMatchErrorTest() {

        matchPresenter.getMatch("")

        argumentCaptor<MatchRepositoryCallback<MatchResponse?>>().apply {

            verify(matchRepository).getNextMatch(eq(""), capture())
            firstValue.onDataError()
        }

        Mockito.verify(view).onShowLoading()
        Mockito.verify(view).onDataError()
        Mockito.verify(view).onHideLoading()
    }*/*/




    @Test
    fun testDoRequest() {
        //Network.getService().prevMatch("4328")
/*        val apiRepository = mock(Network::class.java)
      // val url = "https://www.thesportsdb.com/api/v1/json/1/search_all_teams.php?l=English%20Premier%20League"
        //apiRepository.doRequest(url)
        apiRepository.getService().prevMatch("4328")
        verify(apiRepository).getService().prevMatch("4328")*/

        routes = Network.getService()
        scheduleUtils = ScheduleUtils

        val bp = BasePresenter<NextMatchView>()
        bp.subscribe(routes.nextMatch("4328")
                .compose(scheduleUtils.set<MatchEvent>())
                .subscribe(
                        { res ->
                            run {
                                Mockito.verify(view).onNextMatchData(res)
                            }
                        }

                ))


    }
}